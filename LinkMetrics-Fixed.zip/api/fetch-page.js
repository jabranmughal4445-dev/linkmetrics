// Vercel serverless function for LinkMetrics.
// It fetches public HTML server-side so the browser is not blocked by CORS.
// Basic SSRF protections are included: only public http/https hosts are allowed.

const dns = require('node:dns').promises;
const net = require('node:net');

function isPrivateIp(ip) {
  if (!ip) return true;
  if (net.isIPv4(ip)) {
    const [a,b,c,d] = ip.split('.').map(Number);
    return (
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 198 && (b === 18 || b === 19)) ||
      a === 0
    );
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    return x === '::1' ||
      x === '::' ||
      x.startsWith('fc') ||
      x.startsWith('fd') ||
      x.startsWith('fe80:') ||
      x.startsWith('::ffff:127.') ||
      x.startsWith('::ffff:10.') ||
      x.startsWith('::ffff:192.168.') ||
      x.startsWith('::ffff:172.');
  }
  return true;
}

async function assertPublicHost(hostname) {
  const h = hostname.toLowerCase();
  if (
    h === 'localhost' ||
    h.endsWith('.localhost') ||
    h.endsWith('.local') ||
    h.endsWith('.internal') ||
    h === 'metadata.google.internal'
  ) {
    throw new Error('Private host blocked');
  }

  // If hostname itself is an IP, validate it directly.
  if (net.isIP(h)) {
    if (isPrivateIp(h)) throw new Error('Private address blocked');
    return;
  }

  const records = await dns.lookup(h, { all: true, verbatim: true });
  if (!records.length || records.some(r => isPrivateIp(r.address))) {
    throw new Error('Private or unavailable address blocked');
  }
}

async function fetchPublic(urlString) {
  let current = new URL(urlString);

  for (let hop = 0; hop <= 3; hop++) {
    if (!['http:', 'https:'].includes(current.protocol)) {
      throw new Error('Only HTTP and HTTPS URLs are supported');
    }

    await assertPublicHost(current.hostname);

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 25000);

    let response;
    try {
      response = await fetch(current.href, {
        method: 'GET',
        redirect: 'manual',
        signal: controller.signal,
        headers: {
          'User-Agent': 'LinkMetrics/1.0 (+public-page-analysis)',
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5',
          'Accept-Language': 'en-US,en;q=0.8'
        }
      });
    } finally {
      clearTimeout(timer);
    }

    if ([301,302,303,307,308].includes(response.status)) {
      if (hop === 3) throw new Error('Too many redirects');
      const location = response.headers.get('location');
      if (!location) throw new Error('Redirect without destination');
      current = new URL(location, current.href);
      continue;
    }

    const contentType = (response.headers.get('content-type') || '').toLowerCase();
    if (!response.ok) {
      const err = new Error('Target returned HTTP ' + response.status);
      err.status = response.status;
      err.kind = 'target_http';
      throw err;
    }

    if (contentType && !/html|xml|text\//.test(contentType)) {
      const err = new Error('Target did not return HTML');
      err.kind = 'type';
      throw err;
    }

    const len = Number(response.headers.get('content-length') || 0);
    if (len && len > 5_000_000) {
      throw new Error('Page is larger than 5 MB');
    }

    const html = await response.text();
    if (!html.trim()) throw new Error('Empty page');

    return { html: html.slice(0, 3_000_000), finalUrl: current.href };
  }

  throw new Error('Could not fetch page');
}

module.exports = async function handler(req, res) {
  if (req.method === 'OPTIONS') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    return res.status(204).end();
  }

  if (req.method !== 'GET') {
    return res.status(405).json({ kind: 'http', message: 'Method not allowed' });
  }

  const raw = req.query && req.query.url;
  if (!raw || typeof raw !== 'string') {
    return res.status(400).json({ kind: 'http', message: 'Missing URL' });
  }

  let u;
  try {
    u = new URL(raw);
  } catch {
    return res.status(400).json({ kind: 'http', message: 'Invalid URL' });
  }

  if (!['http:', 'https:'].includes(u.protocol)) {
    return res.status(400).json({ kind: 'http', message: 'Only HTTP and HTTPS URLs are supported' });
  }

  try {
    const result = await fetchPublic(u.href);
    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json(result);
  } catch (e) {
    const message = e && e.name === 'AbortError'
      ? 'The target website took too long to respond.'
      : (e && e.message) || 'Could not fetch the target website.';

    const kind = e && e.kind === 'type' ? 'type' :
      e && e.kind === 'target_http' ? 'http' : 'blocked';

    return res.status(502).json({
      kind,
      status: e && e.status ? e.status : 502,
      message
    });
  }
};
