# LinkMetrics — fixed CORS version

This version fixes the browser CORS problem by fetching public pages through `/api/fetch-page`.

## Deploy
1. Put this folder in a GitHub repository, or upload it to Vercel.
2. Deploy the project as a normal Vercel project.
3. Open the deployed website URL.
4. Enter the publisher URL, anchor text, and target URL.
5. Click **Find placement**.

Important: do not open `index.html` directly with `file://`. The `/api/fetch-page` endpoint must be running on the same deployed site.

## What it fixes
- Normal cross-origin/CORS failures from browser `fetch()`
- Redirect handling
- Basic SSRF protection
- HTML/text content checks
- Clear errors for blocked/slow/non-HTML pages

Some websites still cannot be analyzed because they block automated requests or build their article text only after JavaScript runs in a real browser. This version does not pretend it can read those pages.
